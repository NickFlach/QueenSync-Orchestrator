#!/usr/bin/env bash
# apply.sh — apply this PR locally. Run from the root of your Kannaktopus checkout.
set -euo pipefail

BRANCH="feat/observatory-presence"
ZIP="${1:-kannaktopus-observatory-presence.zip}"

if [[ ! -f "$ZIP" ]]; then
  echo "Zip file not found: $ZIP" >&2
  exit 1
fi

# 1. Branch off your default branch.
git checkout -b "$BRANCH"

# 2. Drop the new files into place (no existing files are touched).
unzip -o "$ZIP" -x apply.sh PR_BODY.md
chmod +x scripts/queensync_presence.py

# 3. Stage + commit.
git add scripts/queensync_presence.py \
        scripts/lib/nats-publish.sh \
        scripts/systemd/kannaktopus-presence.service \
        docs/observatory-presence.md

git commit -m "feat(observatory): publish queen.event.join presence on swarm bus" \
           -m "Adds a small NATS presence beacon so a running Kannaktopus shows up on observatory.ninja-portal.com and flips its arm card on the QueenSync Queen Console from offline to idle. Opt-in, fault-tolerant, no existing files modified."

# 4. Push your branch.
git push -u origin "$BRANCH"

echo
echo "Branch pushed. Open a PR using PR_BODY.md as the description, e.g.:"
echo "  gh pr create --title 'Wake Kannaktopus on the Kannaka Constellation observatory' --body-file PR_BODY.md"
